/**
 * Automatically generated file. DO NOT MODIFY
 */
package io.flutter.plugins.webviewflutter;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "io.flutter.plugins.webviewflutter";
  public static final String BUILD_TYPE = "debug";
}
